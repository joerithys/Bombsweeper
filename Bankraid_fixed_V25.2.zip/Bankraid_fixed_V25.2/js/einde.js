function toon_einde(){
		
	var $letter					= new Array();
		$letter[1]					= '#divB2';
		$letter[2]					= '#dive1';
		$letter[3]					= '#divy';
		$letter[4]					= '#dive2';			
		
	var $width					= new Array();
		$width[1]					= 140;
		$width[2]					= 140;
		$width[3]					= 140;
		$width[4]					= 140;			
			
	var $height					= new Array();
		$height[1]					= 200;
		$height[2]					= 200;
		$height[3]					= 200;
		$height[4]					= 200;			
			
	var $marginBottom					= new Array();
		$marginBottom[1]					= 0;
		$marginBottom[2]					= 0;
		$marginBottom[3]					= -70;
		$marginBottom[4]					= 0;			
			
		reset_sidebar_menu();
		save_all_at_end();
		wisselVak("end_body");						//Show end screen
//		$("#labyrinths_changed").html(0);
//		$("#scores_changed").html(0);		
		run_extro();
			
	function run_extro(){							//Show endanimation
		$(document).stop(true, true);				//stop all script, empty queue and jump to end of script)
		$(".indexHeader").html('<img src="images/walking-animation-up.gif" class="deliveryMan null" />');
		$(".deliveryMan").removeAttr("style");
		$('#end_flyzy').addClass('null');
		$('#end_title').addClass('null');
		$('#end_owner').addClass('null');
		$time_out = setTimeout("$('#end_flyzy').removeClass('null')", 500);
		zoomOut_end_title();
		$time_out = setTimeout("$('#end_title').removeClass('null')", 2000);
		zoomIn_end_title();
		$('.deliveryMan').removeClass("null");
		$time_out = setTimeout("Move_test()", 5000);
		$time_out = setTimeout("$('#end_owner').removeClass('null')", 12000);
		$time_out = setTimeout('$(".deliveryMan").addClass("null")', 22000);
	}

	function zoomOut_end_title(){
		for($i=1;$i<9;$i++){
			$($letter[$i]).html(zoomOut);
		};
	}
			
	function zoomIn_end_title(){
		for($i=1;$i<9;$i++){
			$($letter[$i]).html(zoom_In);
		};
	}
									
	function zoom_In(e){	//Enlarge letters animated
		$(this)
			.css({
				'z-index':1,
			})
			.animate({
				opacity:1,
				width:$width[$i],
				height:$height[$i],
				marginBottom:$marginBottom[$i],
				top:1,						
				left:1						
			},1300)
		;
	}			
}
		
function finished() {
	var $gate = new Audio('audio/gate.mp3'); 
	var $bonus_multiplier = 0;
	remove_unnecessary_items ();
	set_all_walls();
	fill_safes();
	setTimeout(function(){
		$('#body_title span').html("Bank Secured!");
		if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
			$gate.play();
		};
	},7000);
	if (walkers_left()) {
		$pos = get_positions($("#klok"));	//get preset position of mover
		$('#walkers_left div').each( function($i, $item) {
			$($item).hasClass('null')?do_nothing('No walkers left @ ' + $i):walker_left_bonus($i, $item);
			$($item).hasClass('null')?do_nothing('No walker bonus'):$bonus_multiplier++;
		});
	}
	setTimeout(function(){
		level_solved();
	},10000 + ($bonus_multiplier * 200));
	setTimeout(function(){
		parseInt($("#score_value").html()) > parseInt($("#top_ten td:last").html()) ? 
			setTimeout(function(){
				save_score(); 		
			},3000 + ($bonus_multiplier * 550))
		:
			setTimeout(function(){
				do_nothing("no high score, sorry! : " + parseInt($('#score_value').html()) + " > " + parseInt($("#top_ten td:last").html()));
				toon_menu();
			},4000 + ($bonus_multiplier * 550));
		},15000 + ($bonus_multiplier * 550));
}		
	
function remove_bombs() {
	$('.bomb_hor').each( function($i, $item) {
		setTimeout(function(){
			$($item).addClass('null');
		},100 + ( $i * 100 ));
	});
	$('.bomb_vert').each( function($i, $item) {
		setTimeout(function(){
			$($item).addClass('null');
		},100 + ( $i * 100 ));
	});
}
	
function set_all_walls() {
	$(".muur_hor").each( function($i, $item) {
		setTimeout(function(){
			$($item).removeClass("null");
		},100 + ( $i * 100 ));
	});
	$(".muur_vert").each( function($i, $item) {
		setTimeout(function(){
			$($item).removeClass("null");
		},100 + ( $i * 100 ));
	});
}
	
function walker_left_bonus($i, $item) {
	var $clock_pos = get_positions($("#klok"));	//get preset position of clock
	var $walk_pos = get_positions($($item));	//get preset position of mover
	var $top = $clock_pos.top - $walk_pos.top;
	var $left = $clock_pos.left - $walk_pos.left;
	var $bonus = new Audio('audio/kung_fu_punch.mp3'); 
	setTimeout(function(){
		var $clock_pos = get_positions($("#klok"));	//get preset position of clock				
		$('#walker_' + ($i + 1)).css('position', 'absolute');
		$('#walker_' + ($i + 1)).animate({
			'top': ($clock_pos.top + 40),
			'left': ($clock_pos.left + 20),
		}, {
			duration: 900
		});
		if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
			$bonus.play();
		};
		setTimeout(function(){
			$('#walker_' + ($i + 1)).addClass("null");
			$("#klok").html(parseInt($("#klok").html()) + 10);
		},800);
	},6000 + (($i + 3) * 300));
}
	
function remove_unnecessary_items () {
	$walker_direction = $("#mover").rotationInfo().deg;
	$('#score').removeClass('null');
	$('#level').addClass('null');
	remove_bombs();
	for ($i=0; $i<10; $i++) {
		setTimeout(function($i){
			switch($walker_direction) {
				case 90:
					Move_right($('#mover'));
					break;
				case 180:
					Move_down($('#mover'));
					break;
				case -90:
					Move_left($('#mover'));
					break;
				case 0:
					Move_up($('#mover'));
				break;
				default:
					do_nothing("No move @ direction = " + $walker_direction);
				break;
			} 
		},50 + ( $i * 300 ));
	};
}
	
function fill_safes() {
	$(".void_hall").css("background-image", "none");
	$(".void_hall").removeClass("null");
	$(".void_hall").each( function($i, $item) {
		setTimeout(function(){
			$($item).css("background-image", "url(./images/golden_bars_3.png)");
		},200 + ( $i * 200 ));
		setTimeout(function(){
			$($item).html('<img src="images/gate_all.gif?x=' + Date.now() + '" alt="gate" title="peep">');
		},250 + ( $i * 250 ));
	});
}

function game_over() {
	reset_sidebar_menu();
	$('#level b').html(1);
	$(".deliveryMan").removeAttr("style");
	$("#score_value").html('0');
	$(document).stop(true, true);	//stop all script, empty queue and jump to end of script)
	$('.deliveryMan').removeClass('null');
	$('#end_flyzy').addClass('null');
	$('#end_title').addClass('null');
	$('#end_owner').addClass('null');
	$deliveryMan = '<img src="images/walking-animation-up.gif" class="deliveryMan" />';
	$('.indexHeader ').html('<div class="deliveryMan">Game</br>Over</div>');
	wisselVak("end_body");			//Show end screen
//	$("#labyrinths_changed").html(0);
//	$("#scores_changed").html(0);
	$time_out = setTimeout("Move_test()", 1000);
	$time_out = setTimeout("$('.indexHeader ').html($deliveryMan)", 20000);
	$time_out = setTimeout("toon_menu()", 20000);
	reset_walkers_left();
}

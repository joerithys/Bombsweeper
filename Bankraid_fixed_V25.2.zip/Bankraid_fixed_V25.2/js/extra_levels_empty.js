function load_extra_levels() {
	var $extra_levels = new Array;
	return ($extra_levels);
}

function load_extra_levels_sollutions() {
	var $extra_levels_sollutions = new Array;
	return ($extra_levels_sollutions);
}
function load_extra_levels() {
	var $extra_levels = new Array;
	$extra_levels.push("0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,3,1,0,0,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,1,0,1,0,0,0,1,0,1,0,1,0,1,0,1,0,1,0,0,0,1,0,1,0,0,0,1,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,1,0,0,0,1,0,0,1,0,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0");
	console.log("$extra_levels : " + $extra_levels);
	return ($extra_levels);
}

function load_extra_levels_sollutions() { 
	var $extra_levels_sollutions = new Array; 
	$extra_levels_sollutions.push("3,2,3,2,2,3,2,2,3");
	return ($extra_levels_sollutions); 
}
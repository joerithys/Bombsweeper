function toon_intro(){
	var $letter					= new Array();
		$letter[1]					= '#divB';
		$letter[2]					= '#diva1';
		$letter[3]					= '#divn';
		$letter[4]					= '#divk';			
		$letter[5]					= '#divr';
		$letter[6]					= '#diva2';
		$letter[7]					= '#divi';			
		$letter[8]					= '#divd';
		
		wisselVak("pre_body");

	var $width					= new Array();
		$width[1]					= 95;
		$width[2]					= 95;
		$width[3]					= 95;
		$width[4]					= 95;			
		$width[5]					= 95;
		$width[6]					= 95;
		$width[7]					= 70;
		$width[8]					= 95;			
			
	var $height					= new Array();
		$height[1]					= 150;
		$height[2]					= 150;
		$height[3]					= 150;
		$height[4]					= 150;			
		$height[5]					= 150;
		$height[6]					= 150;
		$height[7]					= 150;
		$height[8]					= 150;			
			
	run_intro();
			
	function run_intro(){
		$(".deliveryMan").removeAttr("style");
		$(document).stop(true, true);			//stop all script, empty queue and jump to end of script)
		$('#flyzy').addClass('null');
		$('#title').addClass('null');
		$('#owner').addClass('null');
		$time_out = setTimeout("$('#flyzy').removeClass('null')", 1100);
		zoomOut_title();
		$time_out = setTimeout("$('#title').removeClass('null')", 2000);
		zoomIn_title();
		$time_out = setTimeout("Move_test()", 5000);
		$time_out = setTimeout("$('#owner').removeClass('null')", 12000);
		$time_out = setTimeout("toon_menu()", 25000);
	}

	function zoomIn_title(){
		for($i=1;$i<9;$i++){
			$($letter[$i]).html(zoomIn);
		};
	}
						
	function zoomOut_title(){
		for($i=1;$i<9;$i++){
			$($letter[$i]).html(zoomOut);
		};
	}
			
	function zoomIn(e){		// zoomeffect 
		$(this)
			.css({
				'z-index':1,
			})
			.animate({
				opacity:1,
				width:$width[$i],
				height:$height[$i],
				top:1,						
				left:1						
			},2500)
		;
	}
			
}
						
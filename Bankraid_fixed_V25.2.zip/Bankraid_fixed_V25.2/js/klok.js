var $countdown;
var $countdown_number;
var $tick = new Audio('audio/tick.mp3'); 
var $bomb = new Audio('audio/Bomb-Sound.mp3'); 

function countdown_trigg() {
  countdown_trigger();
	lees_richting_aan();
}

function countdown_init() {
  $countdown_number = 11;
  countdown_trigger();
	lees_richting_aan();
}

function countdown_end() {
  $countdown_number = 1;
  countdown_trigger();
}

function countdown_clear() {
	lees_richting_half();
	clearTimeout($countdown);
}

function countdown_trigger() {
	console.log("!!!   Countdown triggered   !!!");
	if($countdown_number > 0) {
    $countdown_number--;
    $('#klok').html($countdown_number);
		if($countdown_number == '10') {
			$('.bomb_vert').css("background-image", "url(images/bomb_trans_critical.png)");
			$('.bomb_hor').css("background-image", "url(images/bomb_trans_critical.png)");
			$('#klok').css("color", "red");
		}
    if($countdown_number > 0) {
		$countdown = setTimeout('countdown_trigger()', 1000);
			if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
				$tick.play();
			};
		} else {
			$('#klok').html($countdown_number);
			if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
				$bomb.play();
			};
		}; 
	};
	if($countdown_number == '0') {
		lees_richting_uit();
		$(document).stop(true, true);		//stop all script, don't empty queue and jump to end of script)
		$time_needed = $countdown;
		clear_all_timeout();
		$countdown = setTimeout('explode()', 100);
		$countdown = setTimeout('implode()', 4200);
		walkers_left()?setTimeout('speel($level)', 4200):setTimeout("check_score(-1)", 4900);
	}
}

function reset_speelvak() {
	reset_klok();
}

function klok() {
	$countdown_number = 61;
	$('#klok').css("color", "lime");
	$("#klok").removeClass("null");
	console.log('Klok getriggerd');
	countdown_trigger();
}

function reset_klok() {
	$("#klok").addClass("null");
	clearTimeout($countdown);
	$('#klok').html("61");
	$('#klok').css("color", "lime");
	console.log('Klok gereset');
}

function explode() {
	$(".bomb_vert").each(function () {
		$(this).html()=="1"?show_explosion($(this)):do_nothing('Explode vertical bomb');
	});
	$(".bomb_hor").each(function () {
		$(this).html()=="1"?show_explosion($(this)):do_nothing('Explode horizontal bomb');
	});
	show_explosion($("#mover"));
}

function show_explosion($this) {
	$this.html('<img src="images/explosion3_once.gif?x=' + Date.now() + '" alt="kaboom" title="poof">');
	$this.css('background-image', 'none');
	$that = $this;
	$countdown = setTimeout('explode_stop($that)', 1350);
}

function explode_stop($this) {
	$this.html("1");
}

function implode() {
	show_bombs();
}


var $labyrinth_out = new Array(
		"#1-1", "#1-2", "#1-3", "#1-4", "#1-5", "#1-6", "#1-7", "#1-8", 
		"#1-9", "#1-10", "#1-11", "#1-12", "#1-13", "#1-14", "#1-15", 
/*---------------------------------------------------------------------------------------------*/
		"#2-1", "#2-2", "#2-3", "#2-4", "#2-5", "#2-6", "#2-7", "#2-8", 
		"#2-9", "#2-10", "#2-11", "#2-12", "#2-13", "#2-14", "#2-15", 
/*---------------------------------------------------------------------------------------------*/
		"#3-1", "#3-2", "#3-3", "#3-4", "#3-5", "#3-6", "#3-7", "#3-8", 
		"#3-9", "#3-10", "#3-11", "#3-12", "#3-13", "#3-14", "#3-15", 
/*---------------------------------------------------------------------------------------------*/
		"#4-1", "#4-2", "#4-3", "#4-4", "#4-5", "#4-6", "#4-7", "#4-8", 
		"#4-9", "#4-10", "#4-11", "#4-12", "#4-13", "#4-14", "#4-15", 
/*---------------------------------------------------------------------------------------------*/
		"#5-1", "#5-2", "#5-3", "#5-4", "#5-5", "#5-6", "#5-7", "#5-8", 
		"#5-9", "#5-10", "#5-11", "#5-12", "#5-13", "#5-14", "#5-15", 
/*---------------------------------------------------------------------------------------------*/
		"#6-1", "#6-2", "#6-3", "#6-4", "#6-5", "#6-6", "#6-7", "#6-8", 
		"#6-9", "#6-10", "#6-11", "#6-12", "#6-13", "#6-14", "#6-15", 
/*---------------------------------------------------------------------------------------------*/
		"#7-1", "#7-2", "#7-3", "#7-4", "#7-5", "#7-6", "#7-7", "#7-8", 
		"#7-9", "#7-10", "#7-11", "#7-12", "#7-13", "#7-14", "#7-15", 
/*---------------------------------------------------------------------------------------------*/
		"#8-1", "#8-2", "#8-3", "#8-4", "#8-5", "#8-6", "#8-7", "#8-8", 
		"#8-9", "#8-10", "#8-11", "#8-12", "#8-13", "#8-14", "#8-15", 
/*---------------------------------------------------------------------------------------------*/
		"#9-1", "#9-2", "#9-3", "#9-4", "#9-5", "#9-6", "#9-7", "#9-8", 
		"#9-9", "#9-10", "#9-11", "#9-12", "#9-13", "#9-14", "#9-15", 
/*---------------------------------------------------------------------------------------------*/
		"#10-1", "#10-2", "#10-3", "#10-4", "#10-5", "#10-6", "#10-7", "#10-8", 
		"#10-9", "#10-10", "#10-11", "#10-12", "#10-13", "#10-14", "#10-15", 
/*---------------------------------------------------------------------------------------------*/
		"#11-1", "#11-2", "#11-3", "#11-4", "#11-5", "#11-6", "#11-7", "#11-8", 
		"#11-9", "#11-10", "#11-11", "#11-12", "#11-13", "#11-14", "#11-15"
);

function toon_labyrinth_level() {								//show labyrinth of current level
	wisselVak("body");
	$level = $('#marge_rechts b').html();
	$labyrinth_ex = $('#auto_indicator').html()==0?get_flipped_level($level):get_level($level);
	if ($level==1 && $('#walkers_left > div').length == 6) {
		$('score').html('0');
	}
	construct_labyrinth($labyrinth_ex);
}

function construct_labyrinth($labyrinth_ex) {
	$.each( $labyrinth_ex, function( $i, $value ) {
		(Number($value)!=0)?$($labyrinth_out[$i]).removeClass('null'):$($labyrinth_out[$i]).addClass('null');
		$($labyrinth_out[$i]).html($value);
		switch(Number($value)) {
			case 2:
				$($labyrinth_out[$i]).css("background-image", "url(./images/sweeper_right.png)");
				return $value;
				break;
			case 3:
				$($labyrinth_out[$i]).css("background-image", "url(./images/sweeper_down.png)");
				return $value;
				break;
			case 4:
				$($labyrinth_out[$i]).css("background-image", "url(./images/sweeper_left.png)");
				return $value;
				break;
			case 5:
				$($labyrinth_out[$i]).css("background-image", "url(./images/sweeper_up.png)");
				return $value;
				break;
			default:
				break;
		} 
	});
}

function maak_labyrinth() {												//show full and clickable labyrinth
	wisselVak("body");
	full_set_labyrinth();
	$('#auto_indicator').html("5");
	make_labyrinth_clickable();
}

function make_labyrinth_clickable() {								//show full and clickable labyrinth
	$("#mover").removeAttr("style");
	$(".void_hall").removeClass('null');	
	$(".bomb_hor.null").replaceClass("null","nully");
	$(".bomb_vert.null").replaceClass("null","nully");
	$(".muur_hor.null").replaceClass("null","nully");
	$(".muur_vert.null").replaceClass("null","nully");
	$(".muur_hor").click(function() {
		if ($(this).hasClass("nully")) {
			$(this).removeClass("nully");
			$(this).html(1);
		} else {
			$(this).addClass("nully");
			$(this).html(0);
		};
	});
	$(".muur_vert").click(function() {
		if ($(this).hasClass("nully")) {
			$(this).removeClass("nully");
			$(this).html(1);
		} else {
			$(this).addClass("nully");
			$(this).html(0);
		};
	});
	$(".bomb_hor").click(function() {
		if ($(this).hasClass("nully")) {
			$(this).removeClass("nully");
			$(this).html(1);
		} else {
			$(this).addClass("nully");
			$(this).html(0);
		};
	});
	$(".bomb_vert").click(function() {
		if ($(this).hasClass("nully")) {
			$(this).removeClass("nully");
			$(this).html(1);
		} else {
			$(this).addClass("nully");
			$(this).html(0);
		};
	});
	$(".void_hall").click(function() {
		var $value = $(this).html() < 2 ? 1 : $(this).html();
			$value++;
		switch(Number($value)) {
			case 2:
				previous_labyrinth_walker_present();
				$(this).css("background-image", "url(./images/sweeper_right.png)");
				$(this).html(2);
			break;
			case 3:
				$(this).css("background-image", "url(./images/sweeper_down.png)");
				$(this).html(3);
			break;
			case 4:
				$(this).css("background-image", "url(./images/sweeper_left.png)");
				$(this).html(4);
			break;
			case 5:
				$(this).css("background-image", "url(./images/sweeper_up.png)");
				$(this).html(5);
			break;
			default:
				$(this).css("background-image", "none");
				$(this).html(0);
			break;
		} 
	});
}

function reset_labyrinth() {										//put labyrinth counters to a default state
	var $prev_menu_button = '<a href="#" class="play_interupt" onclick="ask_level()" id="input_ask_level">Play from a level</a>';
	var $normal_menu_button = '<a href="#" class="play_interupt" onclick="toon_oplossing()" id="ref">Show solution</a>';
	var $demo_menu_button = '<a href="#" class="play_interupt" onclick="speel(0)" id="ref">Play full game</a>';
	var $sollution_menu_button = '<a href="#" class="play_interupt" onclick="speel(-1)" id="ref">Play again</a>';
	$('#menu_knop li:nth-child(4)').html($prev_menu_button);
	reset_delete_level_button();
	$(".indexHeader").html('<img src="images/walking-animation-up.gif" class="deliveryMan null" />');
	reset_sidebar_menu();
	$('.deliveryMan').animationDuration = "0s";
	$('.deliveryMan').addClass("null");							//hide the intro sweeper
	$("#mover").addClass("null"); 									//hide the movable sweeper
	$("#score").removeClass("null");
	$("#walkers_left").removeClass("null");
	$("#level").removeClass("null");
	$('.bomb_hor').removeClass('nully');
	$('.bomb_vert').removeClass('nully');
	$('.muur_hor').removeClass('nully');
	$('.muur_vert').removeClass('nully');
	($("#level b").html() < 0) || (Number($('#auto_indicator').html()) == 5) ? $("#level b").html(1) : do_nothing("Level ok");
	switch($('#body_title span').html()) {
		case "Demo":
			$menu_button = $demo_menu_button;
			break;
		case "This is how it's done!":
			$menu_button = $sollution_menu_button;
			break;
		default:
			$menu_button = $normal_menu_button;
			break;
	} 
	$('#zij_knop li:nth-child(3)').html($menu_button);
	clear_all_timeout();
	reset_klok();																		//
	lees_richting_uit();  													//Stop reading keystrokes
	wisselVak("body");															//show only the labyrinth body
	blok_labyrinth();																//make labyrinth unchangable
	show_bombs();
//	$level = $('#marge_rechts b').html();						//
//	$level = (Number($('#auto_indicator').html()) == 5) ? 1 : $('#marge_rechts b').html();
	$('#auto_indicator').html("0");									//reset the autoplay indicator
	$(document).stop(true, true);										//stop all script, empty queue and jump to end of script)
	console.log('Labyrinth is reset !');		
}

function full_set_labyrinth() {										//put labyrinth to the full default state without counters
	var $new_last_level = Number($("#last_level").html()) + 1;
	console.log("$new_last_level : " + $new_last_level);
  $('#body_title span').unblink();
	$('#klok').addClass("null"); 										//hide the clock
	$("#score").addClass("null");										//hide the score
	$("#walkers_left").addClass("null");
	$('#body_title span').html("Click to change your own labyrinth!");
	$('.bomb_hor').css("background-image", "url(./images/bomb_trans_lighted.png)");
	$('.bomb_vert').css("background-image", "url(./images/bomb_trans_lighted.png)");
	$(".void_hall").css("background-image", "none");	
	$(".bomb_hor").html(1);	
	$(".bomb_vert").html(1);	
	$(".muur_hor").html(1);	
	$(".muur_vert").html(1);	
	$(".void_hall").html(0);	
	$(".void_hall").removeClass('null');	
	$('.bomb_hor').removeClass('null');
	$('.bomb_vert').removeClass('null');
	$('.muur_hor').removeClass('null');
	$('.muur_vert').removeClass('null');
	$('.bomb_hor').removeClass('nully');
	$('.bomb_vert').removeClass('nully');
	$('.muur_hor').removeClass('nully');
	$('.muur_vert').removeClass('nully');
	$('#zij_knop li:nth-child(3)').html('<a href="#" class="play_interupt" onclick="save_labyrinth()" id="ref">Save labyrinth</a>');
	$('#zij_knop li:nth-child(4)').html('<a href="#" class="play_interupt" onclick="pre_check_score(-2)">Exit</a>');
	reset_delete_level_button();
	$('#marge_rechts b').html($new_last_level);
	reset_walkers_left();
	console.log('Labyrinth is fully set !');		
}

function blok_labyrinth(){													//make labyrinth unchangable
	$(".muur_hor").off('click');
	$(".muur_vert").off('click');
	$(".bomb_hor").off('click');
	$(".bomb_vert").off('click');
	$(".void_hall").off('click');
	console.log('Labyrinth is blocked !');	
}

function show_bombs() {														//make all bombs visible
	$('.bomb_hor').css("background-image", "url(images/bomb_trans_lighted.png)");
	$('.bomb_vert').css("background-image", "url(images/bomb_trans_lighted.png)");
}

function clear_all_timeout() {										//stop all running timeout functions
	var id = window.setTimeout(function() {}, 0);
	while (id--) {
		window.clearTimeout(id); 											//will do nothing if no timeout with id is present
	}
	$(document).stop(true, true);										//stop all script, don't empty queue and jump to end of script)
}

function save_labyrinth(){
	var $labyrinth_sav = this_labyrinth();
	var $level_exists = level_exists(this_labyrinth());
	if (labyrinth_valid()) {
		if ($level_exists != 0) {
			alert(" Level already exists as number -- " + $level_exists + " -- ! ");
		} else {
			$("#this_extra_level_div").append($labyrinth_sav + "\n");
			$('.nully').replaceClass('nully','null');
			Place_mover();
			$('#body_title span').html("Recording the sollution to your own labyrinth!");
			$('#body_title span').blink({
				delay: 200
			});
			$('#zij_knop li:nth-child(3)').html('<a href="#" class="play_interupt" onclick="back_to_make_labyrinth()" id="ref">Change labyrinth</a>');
			record_moves();
		}
	} else {
		do_nothing(" Labyrinth not valid ! ");
	};	
}

function back_to_make_labyrinth() {
	var $labyrinth_ex = $("#this_extra_level_div").html();
	$('#body_title span').unblink();
	lees_richting_uit();
	$('#body_title span').html("Click to change your own labyrinth!");
	$('#zij_knop li:nth-child(3)').html('<a href="#" class="play_interupt" onclick="save_labyrinth()" id="ref">Save labyrinth</a>');
	$labyrinth_ex = $labyrinth_ex.split(",");
	construct_labyrinth($labyrinth_ex);
	make_labyrinth_clickable();
	$("#this_extra_level_div").html("");
	console.log('Labyrinth is unblocked !');	
}

function this_labyrinth() {
	var $this_labyrinth = new Array();
	$("#speelvak .td").each( function() {
		$this_labyrinth.push(Number($(this).html()));
	});
//	console.log("This labyrinth : \n" + $this_labyrinth);
	return ($this_labyrinth);
}

function put_labyrinths($filename) {
	var $added_levels = 'function load_extra_levels() { \n\tvar $extra_levels = new Array; '
	var $labyrinth_save_success = false;
	$extra_levels_div = $("#extra_levels_div").html().split('\n');
	$.each( $extra_levels_div, function($i, $value) {
		$value!=""?$added_levels += '\n\t$extra_levels.push("' + $value + '");':do_nothing("empty level at pos " + $i);
	});
	$added_levels += ' \n\treturn ($extra_levels); \n}';
	$added_levels += '\n\n'
	$added_levels += 'function load_extra_levels_sollutions() { \n\tvar $extra_levels_sollutions = new Array; '
	$extra_levels_sollutions_div = $("#extra_levels_sollutions_div").html().split('\n');
	$.each( $extra_levels_sollutions_div, function($i, $value) {
		$value!=""?$added_levels += '\n\t$extra_levels_sollutions.push("' + $value + '");':do_nothing("no lev@pos " + $i);
	});
	$added_levels += ' \n\treturn ($extra_levels_sollutions); \n}';
	save($added_levels, $filename, 'text/plain')?
//		alert('Labyrinth saved! \n Copy the file "extra_levels.js" \n from the download directory to the game directory "Bankraid/js" \n and replace the old one!')
		$labyrinth_save_success = true
	:
//		alert("Save failed")
		$labyrinth_save_success = false
	;	
	return ($labyrinth_save_success);
}	

function labyrinth_valid() {
	var $bombs_accessable = 0;
	var $walker_present = false;
	var $bomb_pos = null;
	var $hor = 0;
	var $vert = 0;
	if(labyrinth_walker_present()) {
		$(".bomb_hor").each(function () {
			$bomb_pos = $(this).attr('id');
			$bomb_pos = $bomb_pos.split('-');
			$hor = Number($bomb_pos[0].match(/\d+/));
			$vert = Number($bomb_pos[1]);
			if (($(this).html()==1)) {
				(($hor==1) && ($("#" + ($hor+1) + "-" + $vert).html()==0)) || (($hor==11) && ($("#" + ($hor-1) + "-" + $vert).html()==0))?$bombs_accessable++:do_nothing("Bomb not accessible @ " + $hor + "-" + $vert)
			}
		});
		$(".bomb_vert").each(function () {
			$bomb_pos = $(this).attr('id');
			$bomb_pos = $bomb_pos.split('-');
			$hor = Number($bomb_pos[0].match(/\d+/));
			$vert = Number($bomb_pos[1]);
			if (($(this).html()==1)) {
				(($vert==1) && ($("#" + $hor + "-" + ($vert+1)).html()==0)) || (($vert==15) && ($("#" + $hor + "-" + ($vert-1)).html()==0))?$bombs_accessable++:do_nothing("Bomb not accessible @ " + $hor + "-" + $vert)
			}
		});
		if($bombs_accessable > 0) {
			return true;
		} else {
			alert("No bomb accessible = no save possible")
			return false;
		};
	} else {
		alert("No walker present = no save possible");
		return false;
	}
}

function previous_labyrinth_walker_present() {
	$(".void_hall").each(function () {
		if($(this).html() > "1") {
//			console.log("Reeds een walker geplaatst op " + $(this).attr("id") + " met waarde : " +$(this).html());
			$(this).html(0);
			$(this).css("background-image", "none");
			return true;
		}
	});
	return false;
}

function labyrinth_walker_present() {
	var walker_present = false;
	$(".void_hall").each(function () {
		if($(this).html() > "1") {
//			console.log("Walker present = save possible");
			walker_present = true;
		}
	});
	return walker_present;
}

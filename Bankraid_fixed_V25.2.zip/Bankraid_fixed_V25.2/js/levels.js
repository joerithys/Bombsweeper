var $added_levels = new Array();
var	$last_level;
var $levels;

function get_level($level) {
	$levels_ = levels();
//	console.log("level = " + $level);
	$levels_[$level] = $levels_[$level].split(',');
	return ($levels_[$level]);
}

function level_solved($next_element) {
	var $seconds_left = $('#klok').html();
	var $klok_time = $seconds_left * 200;
	var sollution_found = false;
	clearTimeout($countdown);
	$direction = lees_richting_uit();
	$interval = 300;
	$next_element?$next_element.addClass("null"):do_nothing("level_solved no next_element");
	if ($('#auto_indicator').html()==1) {
		var $level = $('#marge_rechts b').html();
		$('#auto_indicator').html("0");							//reset the autoplay indicator
		setTimeout(function() {
			switch($('#body_title span').html()){
				case "Demo": // 
					toon_demo();
				break;
				case "This is how it's done!": // 
					speel(-1);
				break;
				default: 
					speel($level);
				break; // 		
			}
		}, 1500);
	} else {
		if ($('#auto_indicator').html()==0) {
			disable_sidebar_menu();
			for ($i = 0; $i < $seconds_left; $i++) { 
				$time_out = setTimeout('count_points()', $interval);
				$interval = $interval + 100;
			};			
			$next_element?$time_out = setTimeout('next_level()', (($klok_time / 2) + 1500)):last_level_congrats();
		} else {
			$('#body_title span').unblink();
			own_level_solved();
		}
	}
}

function own_level_solved() {
	var $labyrinth_sav = this_labyrinth();
	var $sollution = $("#this_level_sollution_div").html();
//	$("#extra_levels_div").append($("#this_extra_level_div").html() + "\n");
//	$("#all_levels_div").append($("#this_extra_level_div").html() + "\n");
	$("#extra_levels_div").append($("#this_extra_level_div").html());
	$("#all_levels_div").append($("#this_extra_level_div").html());
	$("#this_extra_level_div").html("");
//	$("#extra_levels_sollutions_div").append($("#this_level_sollution_div").html() + "\n");
//	$("#all_levels_sollutions_div").append($("#this_level_sollution_div").html() + "\n");
	$("#extra_levels_sollutions_div").append($("#this_level_sollution_div").html());
	$("#all_levels_sollutions_div").append($("#this_level_sollution_div").html());
	$("#this_level_sollution_div").html("");
	$last_level = Number($("#last_level").html()) + 1;
	$("#last_level").html($last_level);
	alert_level_saved("Labyrinth saved!\n")
	$("#labyrinths_changed").html(1);
	$("#level b").html(1);
	toon_menu();
}

function last_level_congrats() {
//	disable_sidebar_menu();	
	var $congrat_text = '<div id="congrats" class="null"></br><span>Congratulations !</span>'
	var $pos = get_positions($("#speelvak .tbody"));
		$congrat_text += '</br>'
		$congrat_text += '<span>Last level solved !</span></br></div>'
	$(".indexHeader").html($congrat_text);
	$walkers_left = 0;
	$('#walkers_left div').each(function($i) {
		$(this).attr("style")?$walkers_left++:do_nothing('walkers_left');
	});
	var $width = $("#speelvak .tbody").width();
	var $height = $("#speelvak .tbody").height();
	var $top = $pos.top;
	var $left = $pos.left;
	$("#congrats")											//zoom out congratulation text
		.css({
			'z-index':0,
		})
		.animate({
			'opacity':0.7,
			'width':1,
			'height':1,
			'font-size': 0,
		},2000)
	;	
	setTimeout('$("#congrats").removeClass("null")',2000);
	$("#congrats").css("background-image", "url(./images/full_black_hard_bkgnd.png)");
	setTimeout(function(){									//zoom in congratulation text
		$("#congrats").animate({
			'top': $top,
			'left': $left,
			'opacity':'1',
			'width': $width,
			'height': $height,
			'font-size': '600%',
		}, {
			duration: 1000
		});
		$("#congrats").rotate({								//rotate congratulation text 360°
			angle: 0,
			animateTo:360
		}, {
			duration: 6000
		})
		;
	},5000 + ($walkers_left * 400));
	setTimeout(function(){
		$("#level b").html(1);
		reset_walkers_left();
		$('#walkers_left').addClass("null");
	},5200 + ($walkers_left * 400));
}

function next_level() {
	var $next_level = Number($('#marge_rechts b').html()) + 1
	if ($next_level > $("#last_level").html()) {
		finished();
	} else {
		reset_sidebar_menu();
		$('#marge_rechts b').html(Number($('#marge_rechts b').html())+1);
		$level = $('#marge_rechts b').html();
		speel($level);
	}
}

function ask_level() {
	var $level = 1;
	var $level_asker = '<form id="input_tag" action="javascript:alert('+"'"+'Fail!'+"'"+');">Play from level <input autocomplete="off" type="text" id="input_ask_level" class="integrated"><input type="submit" value="GO"></form><span id="message"></span>';
	var $prev_button = '<a href="#" onclick="ask_level()" id="input_ask_level">Play from a level</a>';
	if($("#menu_knop li:nth-child(8) a").html() == "Show high-scores" ) {
		$("#menu_knop li:nth-child(7)").html('<a href="#" onclick="delete_level()" id="input_delete_level">Delete an extra level</a>');
	}
	$('#menu_knop li:nth-child(4)').html($level_asker);
	$("#input_ask_level").focus();
	$("form").submit(function( event ) {
		if (($("#input_ask_level").val() < (Number($("#last_level").html()) + 1))&&($("#input_ask_level").val() > 0)) {
			$level = parseInt($("#input_ask_level").val());
			event.preventDefault();	 
			$('#menu_knop li:nth-child(4)').html($prev_button);
			reset_game();
			$('#marge_rechts b').html($level);
			speel($level);
		} else {
			$("#message").text("Shoose between 1 & " + $("#last_level").html() + " !").show().fadeOut(3000);
			event.preventDefault();	 
			return; 
		}
	});
 }

function get_flipped_level($level) {
	$level_ = get_level($level) ? get_level($level) : get_level(0);
	$flippo = randomize(1,4);
	switch($flippo) {
		case 1:
//			console.log("Labyrinth not flipped");
			break;
		case 2:
			$level_ = flip_hor($level_);
//			console.log("Labyrinth horizontally flipped");
			break;
		case 3:
			$level_ = flip_vert($level_);
//			console.log("Labyrinth vertically flipped");
			break;
		case 4:
//			$level_ = flip_full($level_);
			console.log("Labyrinth fully flipped");
			break;
		default:
			console.log("Randomizer failed!!!");;
			break;
	} 
	return $level_;
}

function randomize(min,max) {
    return Math.floor(Math.random()*(max-min+1)+min);
}

function flip_hor($level_) {
	var $rows = 11;
	var $collumns = 15;
	var $multip, $new_place = 1;
	var $temp = new Array();
	$.each( $level_, function($i, $value) {  
		switch(Number($value)) {
		case 2:
			$value = 4;
//			console.log("Walker flipped from right to left");
			break;
		case 4:
			$value = 2;
//			console.log("Walker flipped from left to right");
			break;
		default:
//			console.log("Walker not flipped!");;
			break;
		}
		$multip = Math.floor($i/($collumns)) + 1;
		$new_place = (2*$multip-1)*$collumns-1-$i;
		$temp[$new_place] = $value;
	});
	return $temp;
}

function flip_vert($level_) {
	var $rows = 11;
	var $collumns = 15;
	var $multip, $new_place = 1;
	var $temp = new Array();
	$.each( $level_, function($i, $value) {  
		switch(Number($value)) {
		case 3:
			$value = 5;
		break;
		case 5:
			$value = 3;
		break;
		default:
			do_nothing("Walker not flipped!");;
		break;
		}
		$multip = Math.floor($i/($collumns)) + 1;
		$new_place = (($rows-1)-($multip-1)*2)*$collumns+$i;
		$temp[$new_place] = $value;
	});
	return $temp;
}

function flip_full($level_) {
	var $length = $level_.length;
	var $temp = new Array();
	$.each( $level_, function($i, $value) {
		switch(Number($value)) {
		case 2:
			$value = 4;
		break;
		case 3:
			$value = 5;
		break;
		case 4:
			$value = 2;
		break;
		case 5:
			$value = 3;
		break;
		default:
			do_nothing("Walker not flipped!");;
		break;
		}
		$temp[$length-$i-1] = $value;
	});
	return $temp;
}

function levels() {
	var $levels_, $levels = new Array;
	$levels_ = $("#all_levels_div").html();
	$levels_ = $levels_.split("\n");
	$.each( $levels_, function($i, $value) {
		$value?$levels.push($value):do_nothing("Empty level at position " + $i +  "!");
	});
	return ($levels);
}

/*function add_added_levels($levels_, $added_levels) {
//	console.log("There are " + ($levels_.length - 1) + " original levels.");
	if ((typeof $added_levels !== 'undefined') && ($added_levels.length > 0)) {
		$levels_.push($added_levels);
		console.log($added_levels.length + " levels added !");
	} else {;
		console.log("There are -- NO -- extra levels ");
	}
	$last_level = $levels_.length - 1;
	$("#last_level").html($last_level);
	$.each( $levels_, function($i, $value) {
		$("#all_levels_div").append($value + "\n");
	});
	return $levels_;
}*/

function level_exists($level_2_check) {
	var $level_exists = 0;
	var $existing_levels = levels();
//	console.log("Level 2 check : \n" + $level_2_check);
	$level_2_check = unify_level_walker($level_2_check);
	var $1 = $level_2_check;
	var $2 = flip_hor($level_2_check);
	var $3 = flip_vert($level_2_check);
	var $4 = flip_full($level_2_check);
	$.each($existing_levels, function($e, $value){
		$value = unify_level_walker($value);
//		console.log("-pre- " + $value);
		((JSON.stringify($value) == JSON.stringify($1)) || (JSON.stringify($value) == JSON.stringify($2)) || (JSON.stringify($value) == JSON.stringify($3)) || (JSON.stringify($value) == JSON.stringify($4))) ? 
//		(($value == $1) || ($value == $2) || ($value == $3) || ($value == $4)) ? 
			$level_exists = $e 
		: 
			do_nothing("-1- " + JSON.stringify($value) + "\n-2- " + JSON.stringify($1));
	});
//	console.log("Level exists = " + $level_exists);
	return $level_exists;
}

function unify_level_walker($labyrinth) {
//	console.log("$labyrinth before : " + $labyrinth);
	$.isArray($labyrinth) ? do_nothing : $labyrinth = $labyrinth.split(",");
	$.each($labyrinth, function($e, $value){
		if(Number($value) > 2) {
//			console.log("Walker direction changed from " + $value + " to 2 .");
			$labyrinth[$e] = 2;
		} else {
			$labyrinth[$e] = Number($labyrinth[$e]);
		};
	});
//	console.log("$labyrinth after  : " + $labyrinth);
	return $labyrinth;
}

function delete_level() {
	var $org_levels = $("#org_levels_div").html().split('\n');
	var $added_levels = $("#extra_levels_div").html().split('\n');
	var $maximum = Number($("#last_level").html());
	var $minimum = $org_levels.length - 1;
	if ($minimum==$maximum) {
		var $level_asker = '<form id="input_tag" action="javascript:alert('+"'"+'failed !'+"'"+');">Delete level <input autocomplete="off" type="text" id="input_delete_level" value="' + $minimum + '" class="integrated" readonly><input type="submit" value="GO"></form><span id="message"></span>';		
	} else {
		var $level_asker = '<form id="input_tag" action="javascript:alert('+"'"+'failed !'+"'"+');">Delete level <input autocomplete="off" type="text" id="input_delete_level" class="integrated"><input type="submit" value="GO"></form><span id="message"></span>';
	};
	var $prev_button = '<a href="#" onclick="delete_level()" id="input_delete_level">Delete an extra level</a>';
	$("#menu_knop li:nth-child(4)").html('<a href="#" onclick="ask_level()" id="input_ask_level">Play from a level</a>');
	$('#menu_knop li:nth-child(7)').html($level_asker);
	$("#input_delete_level").focus();
	$("form").submit(function( event ) {
		if (($( "#input_delete_level" ).val() < ($maximum + 1))&&($("#input_delete_level").val() > ($minimum - 1))) {
			$level = parseInt($("#input_delete_level").val());
			$('#marge_rechts b').html($level);
			toon_labyrinth_level();			
			event.preventDefault();	 
			reset_delete_level_button();
			$time_out = setTimeout(function() {
				if(confirm("Are you sure you want to delete this?")){
					remove_level_from_file();
				} else {
					$("#level b").html(1);
					toon_menu();				
				}
			}, 200);
		} else {		
			$("#message").text("Shoose between " + $minimum + " & " + $maximum + " !").show().fadeOut(3000);
			event.preventDefault();	 
			return; 
		}
	});
}

function remove_level_from_file() {
	var $all_levels = $("#all_levels_div").html().split("\n");
	var $all_levels_sollutions = $("#all_levels_sollutions_div").html().split("\n");
	var $last_level = Number($("#last_level").html());
	var $org_levels = $("#org_levels_div").html().split('\n');
	var $org_levels_aantal = $org_levels.length - 2;
	var	$this_level =	$('#marge_rechts b').html();
	var $extra_levels = $("#extra_levels_div").html();
	$extra_levels = $extra_levels.split("\n");
	var $moves = $("#extra_levels_sollutions_div").html();
	$moves = $moves.split("\n");
	var $extra_level_position = $this_level - $org_levels_aantal - 1;
	$extra_levels.splice($extra_level_position, 1);
	$moves.splice($extra_level_position, 1);
	$all_levels.splice($this_level, 1);
	$all_levels_sollutions.splice($this_level, 1);
	$("#all_levels_div").html("");
	$.each( $all_levels, function($i, $value) {
		$("#all_levels_div").append($value + "\n");
	});
	$("#all_levels_sollutions_div").html("");
	$.each( $all_levels_sollutions, function($i, $value) {
		$("#all_levels_sollutions_div").append($value + "\n");
	});
	$("#extra_levels_div").html("");
	$.each( $extra_levels, function($i, $value) {
		$("#extra_levels_div").append($value + "\n");
	});
	$("#extra_levels_sollutions_div").html("");
	$.each( $moves, function($i, $value) {
		$("#extra_levels_sollutions_div").append($value + "\n");
	});
	$("#last_level").html($last_level-1);
	full_set_labyrinth();
	$('#marge_rechts b').html($level);
	alert_level_saved("level " + $level + " removed!\n");
	$("#level b").html(1);
	$("#labyrinths_changed").html(1)
	toon_menu();
}

function alert_level_saved($init_text) {
	var $level_saved_text = '\nTemporarily saved!\nAll changes will be saved\nto your download directory\nwhen the game is ended\nby pressing the "Exit" button\n';
	alert($init_text + $level_saved_text);

}

function reset_delete_level_button() {
	var $extra_levels_left = true;
	var $org_levels = $("#org_levels_div").html().split('\n');
	var $maximum = Number($("#last_level").html());
	var $minimum = $org_levels.length - 1;
	var $delete_extra_level_button = '<a href="#" onclick="delete_level()" id="input_delete_level">Delete an extra level</a>';
	if ($minimum > $maximum) {
		$extra_levels_left = false;
	} 
	if ($("#menu_knop li:nth-child(8) a").html() == "Show high-scores" ) {
		if(!$extra_levels_left) {
			$("#menu_knop li:nth-child(7)").remove();
		} else {
			$("#menu_knop li:nth-child(7)").html($delete_extra_level_button);		
		}
	} else {
		if($extra_levels_left) {
			$("#menu_knop li:nth-child(6)").after('<li><a href="#" onclick="delete_level()" id="input_delete_level">Delete an extra level</a></li>');
		}
	}
}
function toon_menu() {											// toont de menu
	$('#body_title span').html() == "Demo" ? $("#level b").html(1) : do_nothing("Level kept");
	reset_labyrinth();
	$('#body_title span').html("Defuse a bomb, any bomb!");
	wisselVak("menu");
	$('#menu_title').removeAttr('class');
}

function disable_sidebar_menu(){					//
	$(".play_interupt").removeAttr('onClick');
	console.log('play_interupt is blocked !');	
}

function reset_sidebar_menu(){					//
	var $menu_set  = '<li><a href="#" onclick="geluid()">Sound off</a></li>';
			$menu_set += '<li><a href="#" class="play_interupt" onclick="toon_menu()">Show menu</a></li>';
			$menu_set += '<li><a href="#" class="play_interupt" onclick="toon_oplossing()" id="ref">Show solution</a></li>';
			$menu_set += '<li><a href="#" class="play_interupt" onclick="check_score(-2)" id="ref">Exit</a></li>';
	$('#zij_knop').html($menu_set);
		var $menu_scores_set  = '<li><a href="#" onclick="geluid()">Sound off</a></li>';
				$menu_scores_set += '<li><a href="#" class="play_interupt" onclick="toon_menu()">Show menu</a></li>';
				$menu_scores_set += '<li><a href="#" class="play_interupt" onclick="wis_scores()">Reset scores</a></li>';
				$menu_scores_set += '<li><a href="#" class="play_interupt" onclick="check_score(1)" id="ref">Exit</a></li>';
	$('#zij_knop_scores').html($menu_scores_set);
	console.log('play_interupt is unblocked !');	
}

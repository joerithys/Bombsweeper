var $bump = new Audio('audio/Strong_Punch.mp3'); 

function Get_mover_element() {
	var $element = "";
	$.each( $labyrinth_out, function( $i, $value ) {
	  switch($($value).html()) {
			case "2": case "3": case "4": case "5":
				$element = $labyrinth_out[$i];
			break;
	  } 
	});
	return ($element);
}

function Place_mover() {
	$element = Get_mover_element();				//search the div containing the mover
	$pos = get_positions($element);				//get preset position of mover
	$("#mover").css("top", $pos.top);
	$("#mover").css("left", $pos.left);
	$mover_value  = $($element).html();
	$("#mover").css("background-image", "url(./images/sweeper_up.png)");
		switch($mover_value) {
			case "2":
				set_right($("#mover"));
				break;
			case "3":
				set_down($("#mover"));
				break;
			case "4":
				set_left($("#mover"));
				break;
			case "5":
				set_up($("#mover"));	
				break;
			default:
				$("#mover").css("background-image", "url(./images/transparent-question-mark.png)");
				break;
		} 
	$("#mover").removeClass("null");
	$($element).addClass("null");
	return ($mover_value);
}

function Move_test() {
	$('.deliveryMan').removeClass("null"); 			//show the movable sweeper
	$('.deliveryMan').css( { 
        top: "250px",
    } );
	Move_test_up();	
	$time_out = setTimeout("Move_test_up()", 1500);
	$time_out = setTimeout("turn_right_a_u($('.deliveryMan'))", 3000);
	$time_out = setTimeout("Move_test_right()", 3000);	
	$time_out = setTimeout("turn_up_a_r($('.deliveryMan'))", 4800);
	$time_out = setTimeout("Move_test_up()", 4800);	
	$time_out = setTimeout("turn_left_a_u($('.deliveryMan'))", 6100);
	$time_out = setTimeout("Move_test_left()", 6100, "linear");	
	$time_out = setTimeout("turn_down_a_l($('.deliveryMan'))", 11000);
	$time_out = setTimeout("Move_test_down()", 11000);	
	$time_out = setTimeout("turn_right_a_d($('.deliveryMan'))", 13000);
	$time_out = setTimeout("Move_test_right()", 13000);	
	$time_out = setTimeout("turn_down_a_r($('.deliveryMan'))", 14500);
	$time_out = setTimeout("Move_test_down()", 14500);	
	$time_out = setTimeout("Move_test_down()", 16000);	
	$time_out = setTimeout("Move_test_right_final()", 17500);
	$time_out = setTimeout("set_up($('.deliveryMan'))", 19000);
}

function Move_test_up() {
	$('.deliveryMan').animate({
    'top': '-=280px',
	}, {
    duration: 1500
	});
}

function Move_test_left() {
	$('.deliveryMan').animate({
    'left': '-=1100px',
	}, {
    duration: 5000
	});
}

function Move_test_right() {
	$('.deliveryMan').animate({
    'left': '+=350px',
	}, {
		duration: 2000
	});
}

function Move_test_right_final() {
	$('.deliveryMan').animate({
    'left': '+=400px',
	}, {
		duration: 500
	});
}

function Move_test_down() {
		$('.deliveryMan').animate({
		'top': '+=280px',
	}, {
		duration: 1500
	});
}

function Move_right($element) {
	$($element).stop(true, true).animate({
    'left': '+=100px',
	}, {
		duration: 600
	});
}

function Move_down($element) {
	$($element).stop(true, true).animate({
		'top': '+=100px',
	}, {
		duration: 600
	});
}

function Move_left($element) {
	$($element).stop(true, true).animate({
    'left': '-=100px',
	}, {
		duration: 600
	});
}

function Move_up($element) {
	$($element).stop(true, true).animate({
    'top': '-=100px',
	}, {
		duration: 600
	});
}

function set_left($element) {
	$($element).rotate(-90);
}

function set_right($element) {
	$($element).rotate(90);
}

function set_down($element) {
	$($element).rotate(180);
}

function set_up($element) {
	$($element).rotate(0);
}

function turn_left_a_u($element) {
	$($element).rotate({
      	angle: 0,
      	animateTo:-90
	}, {
    duration: 3000
	});
}

function turn_left_a_d($element) {
	$($element).rotate({
      	angle: 180,
      	animateTo:270
	}, {
    duration: 3000
	});
}

function turn_right_a_u($element) {
	$($element).rotate({
      	angle: 0,
      	animateTo:90
	}, {
    duration: 3000
	});
}

function turn_right_a_d($element) {
	$($element).rotate({
      	angle: -180,
      	animateTo:-270
	}, {
    duration: 3000
	});
}

function turn_up_a_l($element) {
	$($element).rotate({
      	angle: -90,
      	animateTo:0
	}, {
    duration: 3000
	});
}

function turn_up_a_r($element) {
	$($element).rotate({
      	angle: 90,
      	animateTo:-0
	}, {
    duration: 3000
	});
}

function turn_down_a_l($element) {
	$($element).rotate({
      	angle: -90,
      	animateTo:-180
	}, {
    duration: 3000
	});
}

function turn_down_a_r($element) {
	$($element).rotate({
      	angle: 90,
      	animateTo:180
	}, {
    duration: 3000
	});
}

function get_positions($element) {
	var $leftPos  = $($element).offset().left;
	var $rightPos = $($element)[0].getBoundingClientRect().right;
	var $topPos   = $($element).offset().top;
	var $bottomPos= $($element)[0].getBoundingClientRect().bottom;
	return {left: $leftPos, right: $rightPos, top: $topPos, bottom: $bottomPos};
}

function go_right($element) {
	var $prev_element = "";
	var $next_element = "";
	var $wall = "";
	var $next_wall = "";
	var $mover = Get_mover_element();			//search the div containing the mover
	set_right($element);
	$element.css("background-image", "url(./images/walking-animation-up.gif)");
	$prev_element = $mover;
	$mover = $mover.split('-');
	$hor = $mover[0].match(/\d+/);
	$vert = $mover[1];
	$next_element = "#" + $hor + "-" + (Number($vert) + 2);
	$wall = '#' + $hor + "-" + (Number($vert) + 1);
	$next_wall = '#' + $hor + "-" + (Number($vert) + 3);
	if ($($wall).html() == 0 || ($($next_wall).html() == 0)) {
		Move_right($element);
		wall_move($wall,$next_wall);
		$($prev_element).html(0);
		$($next_element).html(2);
		if (Number($vert)>12) {
			level_solved($($next_element));
		}
	} else {
		console.log("Move right to : " + $next_element + " not possible");	
		if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
			$bump.play();
		};
	}
}

function go_down($element) {
	var $prev_element = "";
	var $next_element = "";
	var $wall = "";
	var $next_wall = "";
	var $mover = Get_mover_element();				//search the div containing the mover
	set_down($element);
	$element.css("background-image", "url(./images/walking-animation-up.gif)");
	$prev_element = $mover;
	$mover = $mover.split('-');
	$hor = $mover[0].match(/\d+/);
	$vert = $mover[1];
	$next_element = "#" + (Number($hor) + 2) + "-" + $vert;
	$wall = '#' + (Number($hor) + 1) + '-' + $vert;
	$next_wall = '#' + (Number($hor) + 3) + '-' + $vert;
	if ($($wall).html() == 0 || ($($next_wall).html() == 0)) {
		Move_down($element);
		wall_move($wall,$next_wall);
		$($prev_element).html(0);
		$($next_element).html(3);
		if (Number($hor)>8) {
			level_solved($($next_element));
		}
	} else {
		console.log("Move down to : " + $next_element + " not possible");	
		if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
			$bump.play();
		};
	}
}

function go_left($element) {
	var $prev_element = "";
	var $next_element = "";
	var $wall = "";
	var $next_wall = "";
	var $mover = Get_mover_element();	//search the div containing the mover
	set_left($element);
	$element.css("background-image", "url(./images/walking-animation-up.gif)");	
	$prev_element = $mover;
	$mover = $mover.split('-');
	$hor = $mover[0].match(/\d+/);
	$vert = $mover[1];
	$next_element = "#" + $hor + "-" + (Number($vert) - 2);
	$wall = '#' + $hor + "-" + (Number($vert) - 1);
	$next_wall = '#' + $hor + "-" + (Number($vert) - 3);
	if ($($wall).html() == 0 || ($($next_wall).html() == 0)) {
		Move_left($element);
		wall_move($wall,$next_wall);
		$($prev_element).html(0);
		$($next_element).html(4);
		if (Number($vert)<4) {
			level_solved($($next_element));
		}
	} else {
		console.log("Move left to : " + $next_element + " not possible");	
		if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
			$bump.play();
		};
	}
}

function go_up($element) {
	var $prev_element = "";
	var $next_element = "";
	var $wall = "";
	var $next_wall = "";
	var $mover = Get_mover_element();	/*search the div containing the mover*/
	set_up($element);
	$element.css("background-image", "url(./images/walking-animation-up.gif)");	
	$prev_element = $mover;
	$mover = $mover.split('-');
	$hor = $mover[0].match(/\d+/);
	$vert = $mover[1];
	$next_element = "#" + (Number($hor) - 2) + "-" + $vert;
	$wall = '#' + (Number($hor) - 1) + '-' + $vert;
	$next_wall = '#' + (Number($hor) - 3) + '-' + $vert;	
	if ($($wall).html() == 0 || ($($next_wall).html() == 0)) {
		Move_up($element);
		wall_move($wall,$next_wall);
		$($prev_element).html(0);
		$($next_element).html(5);
		if (Number($hor)<4) {
			level_solved($($next_element));
		}
	} else {
		console.log("Move up to : " + $next_element + " not possible");	
		if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
			$bump.play();
		};
	}
}

function wall_move($wall,$next_wall) {
	if ($($wall).html() == 1) {
		$($next_wall).html($($wall).html());
		$($next_wall).removeClass("null");
	}
	$($wall).html(0);
	$($wall).addClass("null");
}

function walkers_left() {
	$walkers_left = 6;
	$walker_deleted = false;
	$('#walkers_left > div').each(function () {
		if ($(this).hasClass("null")) {
			$walkers_left--
		} else {
			if((!$walker_deleted) && (!$("#level").hasClass("null"))) {
				$walker_deleted = true;
				$(this).addClass("null");
			}
		}
	});
	return ($walkers_left>0?true:false);
}

function reset_walkers_left() {
	$(".walker").each(function () {
		$(this).removeClass('null');
		$(this).removeAttr('style');
	});
}

$.fn.rotationInfo = function() {
	var el = $(this),
			tr = el.css("-webkit-transform") || el.css("-moz-transform") || el.css("-ms-transform") || el.css("-o-transform") || '',
			info = {rad: 0, deg: 0};
	if (tr = tr.match('matrix\\((.*)\\)')) {
		tr = tr[1].split(',');
		if(typeof tr[0] != 'undefined' && typeof tr[1] != 'undefined') {
			info.rad = Math.atan2(tr[1], tr[0]);
			info.deg = parseFloat((info.rad * 180 / Math.PI).toFixed(1));
		}
	}
	return info;
};
			
function moves() {
	var $moves_, $moves = new Array;
	$moves_ = $("#all_levels_sollutions_div").html();
	$moves_ = $moves_.split("\n");
	$.each( $moves_, function($i, $value) {
		$value?$moves.push($value):do_nothing("Empty move at position " + $i +  "!");
	});
	return ($moves);
}

function get_moves($level) {
	$moves_ = moves();
	$moves_[$level] = $moves_[$level].split(',');
	return ($moves_[$level]);
}

function record_moves() {
	var $sollution_moves = new Array;
	blok_labyrinth();
	$(document).unbind("keydown");
	$(document).stop( true, true ).keydown(function(e) {
		e.preventDefault(); 				// prevent the default action (like scroll)
		console.log(e.which + " pressed!");
		switch(e.which) {
			case 37: // left
				move_append("4");
				go_left($("#mover"));
			break;
			case 38: // up
				move_append("5");
				go_up($("#mover"));
			break;
			case 39: // right
				move_append("2");
				go_right($("#mover"));
			break;
			case 40: // down
				move_append("3");
				go_down($("#mover"));
			break;
			case 83: // "s"
//				console.log('"S" pressed, "back_to_make_labyrinth()" should start');
				back_to_make_labyrinth();
				return;
			break;
			default: do_nothing("solving");//return; 						// exit this handler for other keys
		};
	});	
}

function move_append($move) {
	if ($("#this_level_sollution_div").html().length != 0) {
		$("#this_level_sollution_div").append(",");
	};
	$("#this_level_sollution_div").append($move);
}
			
function zoomOut(e){
	$(this)
		.css({
			'z-index':0,
		})
		.animate({
			opacity:0.7,
			width:1,
			height:1,
			top:34,						
			left:34						
		},2000)
	;
}

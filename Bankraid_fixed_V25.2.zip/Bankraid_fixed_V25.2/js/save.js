function check_save_possible() {
	// Check for the various File API support.
	if (window.File && window.FileReader && window.FileList && window.Blob) {
	  // Great success! All the File APIs are supported.
	  console.log("Great success! All the File APIs are supported.");
	} else {
	  alert('The File APIs are not fully supported in this browser.');
	}
}

function save(contents, name, mime_type) {
	mime_type = mime_type || "text/plain";
	var blob = new Blob([contents], {type: mime_type});
	var dlink = document.createElement('a');
	dlink.download = name;
	dlink.href = window.URL.createObjectURL(blob);
	dlink.onclick = function(e) {
		// revokeObjectURL needs a delay to work properly
		var that = this;
		setTimeout(function() {
			window.URL.revokeObjectURL(that.href);
		}, 1500);
	};
	dlink.click();
	dlink.remove();
	return true;
}

function save_all_at_end() {
	var $labyrinth_save_success = false;
	var $scores_save_success = false;
	var $labyrinth_save_text = "";
	var $scores_save_text = "";
	$("#level").addClass("null");
	Number($("#labyrinths_changed").html())==1 ? 
		$labyrinth_save_success = put_labyrinths("extra_levels.js") 
	: 
		$labyrinth_save_text = "No labyrinths changed. \n"
	;		
	Number($("#scores_changed").html())==1 ? 
		$scores_save_success = $write_scores_to_file("scores_file.js")
	:
		$scores_save_text = "No high-scores changed. \n"
	;
	$labyrinth_save_success ?
		$scores_save_success ?
			$labyrinth_save_text = '\n\nLabyrinths and scores saved! \nCopy the files "extra_levels.js" and "scores_file.js" \nfrom your download directory \nto the game directory "Bankraid/js" \nand replace the old ones! \n'
		:
			$scores_save_text=="" ? 
				$labyrinth_save_text = 'Labyrinths saved! \nCopy the file "extra_levels.js" \nfrom the download directory \nto the game directory "Bankraid/js" \nand replace the old one! \n\nSaving the scores failed!'
			:
				$labyrinth_save_text = 'Labyrinths saved! \nCopy the file "extra_levels.js" \nfrom the download directory \nto the game directory "Bankraid/js" \nand replace the old one!\n\n' + $scores_save_text
	:
		$labyrinth_save_text=="" ?
			$scores_save_success ?
				$labyrinth_save_text = '\n\nSaving the labyrinths failed!\n Scores saved! \nCopy the file "scores_file.js" \nfrom your download directory \nto the game directory "Bankraid/js" \nand replace the old one! \n'
			:
				$scores_save_text=="" ? 
					$labyrinth_save_text = 'Saving the labyrinths \nand the scores failed! \nNothing saved! \n'
				:
					$labyrinth_save_text = 'Saving the labyrinths failed!\n' + $scores_save_text + "\nNothing saved! \n"
		:
			$scores_save_success ?
				$labyrinth_save_text = $labyrinth_save_text + '\nScores saved! \nCopy the file "scores_file.js" \nfrom your download directory \nto the game directory "Bankraid/js" \nand replace the old one! \n'
			:
				$scores_save_text=="" ? 
					$labyrinth_save_text = $labyrinth_save_text + 'Saving the scores failed! \nNothing saved! \n'
				:
					$labyrinth_save_text = $labyrinth_save_text + $scores_save_text + "Nothing saved! \n"
	;
	alert($labyrinth_save_text);
	$("#labyrinths_changed").html(0);
	$("#scores_changed").html(0);		
}
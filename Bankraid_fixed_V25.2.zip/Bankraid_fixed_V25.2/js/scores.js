function count_points() {
	$('#klok').html(Number($('#klok').html())-1);
	$('#score_value').html(Number($('#score_value').html())+1);
	if($('#menu_knop li:nth-child(2) a').html()=="Sound off") {
		$tick.play();
	};
}

function save_score($indicator) {
	var $score = $('#score_value').html();
	var $score_file = new Array();
	$(".indexHeader").html("");
	get_player_initials($indicator);
}

function toon_scores() {
	clear_all_timeout();
	reset_sidebar_menu();
	wisselVak("top_ten_scores");
	$("#top_ten_scores_title").removeAttr('class');
}

function get_scores() {
	var $score_file = new Array();
	var $player = new Array();
	var $score = new Array();
	$score_file = $read_scores_from_file();
	$.each( $score_file, function( $i, $value ) {
		$score_file_x = $value.split(':');
		$player[$i] = $score_file_x[0];
		$score[$i] = Number($score_file_x[1]);
	});
	$(".hi_score").each( function($i) {
		$("#player_" + ($i + 1)).html($player[$i]);
		$(this).html($score[$i]);
	});
	console.log("Scores loaded!");
}

function get_player_initials($indicator) {
	var $initial_asker = '<form id="top_ten_input_tag" action="javascript:alert('+"'"+'failed!'+"'"+');"> <input autocomplete="off" type="text" id="input_name" class="integrated"><input type="submit" value="Save"></form><span></span>';
	var $prev_title = $('#top_ten_scores_title span').html();
	toon_scores();
	disable_sidebar_menu();
	$('#top_ten_scores_title span').html("Put in your initials (max 10 chars.)!");
	$ranking = get_ranking_place();
	$("#player_" + $ranking).html($initial_asker);
	$("#input_name").focus();
	$("#score_value").html(0);
	$("form").submit(function( event ) {
		if (($("#input_name").val().length < 11) && ($("#input_name").val().length > 0)) {
			event.preventDefault();	 
			$name = $("#input_name").val();
			$initials = $name.length;
			$("#player_" + $ranking).html($name);
			$('#top_ten_scores_title span').html($prev_title);
//			Number($('#level b').html()) == -1?alert_level_saved("Scores saved!\n"):do_nothing("straight to showing the end!");
			$("#scores_changed").html(1);
//			Number($indicator) == -2 ? do_nothing("Going to end.") : alert_level_saved("Scores saved!\n");
//			Number($indicator) == -2 ? toon_einde() : walkers_left()?toon_menu():Number($('#level b').html()) == -1?
			console.log("$indicator @ get_player_initials : " + $indicator);
			if ((Number($indicator) == -2) || (Number($indicator) == 1)) {
				toon_einde(); 
			} else {
				alert_level_saved("Scores saved!\n");
				walkers_left() ? 
					toon_menu() 
				: 
					Number($('#level b').html()) == -1 ? 
						game_over() 
					: 
						toon_menu();
			}
		} else {
			$("#player_" + $ranking + " span").text("Length initials between 1 & 10!").show().fadeOut(3000);
			event.preventDefault();	 
			return; 
		}
	});
}

function get_ranking_place() {
	var $new_name = "nobody";
	var $old_name = "nobody";
	var $new_score = parseInt($('#score_value').html());
	var $old_score = 0;
	var $ranking = 0;
	$(".hi_score").each( function($i) {
		if ($new_score > $(this).html()) {
			$ranking==0?$ranking=$i+1:do_nothing("No more high score @ place " + ($i + 1));
			$old_score = $(this).html();
			$(this).html($new_score);
			$old_name = $("#player_" + ($i + 1)).html();
			$("#player_" + ($i + 1)).html($new_name);
			$new_score = $old_score;
			$new_name = $old_name;
		}
	});
	$ranking==0 ? $ranking=11 : do_nothing("$ranking : " + $ranking);
	return $ranking;
}

function wis_scores() {
	var $scores = '<tr><th></th><th>Player </th><th></th><th>Score</th></tr>';
			$scores += '<tr><td> 1 : </td><td id="player_1">Flyzy</td><td> : </td><td class="hi_score">999</td></tr>';
			$scores += '<tr><td> 2 : </td><td id="player_2">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td> 3 : </td><td id="player_3">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td> 4 : </td><td id="player_4">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td> 5 : </td><td id="player_5">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td> 6 : </td><td id="player_6">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td> 7 : </td><td id="player_7">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td> 8 : </td><td id="player_8">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td> 9 : </td><td id="player_9">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
			$scores += '<tr><td>10 : </td><td id="player_10">NoName</td><td> : </td><td class="hi_score">0</td></tr>';
	$("#top_ten").html($scores);
}

function make_score_file() {
	var $score_file = new Array();
	$score_file = "function $read_scores_from_file() {";
	$score_file += "\n//\tconsole.log('The scores should be read from file ' + $score_txt_file + ' ! ');";
	$score_file += "\n\tvar $scores = '<tr><th></th><th>Player </th><th></th><th>Score</th></tr>';";
	$(".hi_score").each( function($i) {
		$score_file += "\n\t\t$scores += '<tr><td> " + ($i + 1) + ' : </td><td id="player_' + ($i + 1) + '">' + $("#player_" + ($i + 1)).html() + '</td>';
		$score_file += '<td> : </td><td class="hi_score">' + $(this).html() + "</td></tr>';";
	});
	$score_file +=  '\n\t$("#top_ten").html($scores);\n//	return make_score_file();\n}\n'
	return $score_file;
}

function $write_scores_to_file($score_txt_file) {
	var $score_file = make_score_file();
	var $scores_save_success = false;
	save($score_file, $score_txt_file, 'text/plain')?
		$scores_save_success = true
	:
		$scores_save_success = false
	;
	return $scores_save_success;		
}

function pre_check_score($indicator) {
	if(confirm("Are you sure you want to exit?\nThis labyrinth will not be saved with the others!")){
		check_score($indicator);
	} else {
		return;				
	}
}

function check_score($indicator) {
	clear_all_timeout();
	console.log("Checking scores...");
	$(document).stop(true, true);									//stop all script, don't empty queue and jump to end of script)
	reset_klok();													//
	lees_richting_uit();  											//Stop reading keystrokes
	$score_value = parseInt($("#score_value").html());
	$top_ten_lowest_score = parseInt($("#top_ten td:last").html());
	$('#level b').html($indicator);
	$score_value > $top_ten_lowest_score ?
		save_score($indicator)
	:
		walkers_left() ?
			toon_einde()
		:
			Number($indicator) == -1 ?
				game_over()
			:
				toon_einde();
	;
}

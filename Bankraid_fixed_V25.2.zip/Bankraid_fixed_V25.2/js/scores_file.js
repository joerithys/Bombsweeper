function $read_scores_from_file() {
//	console.log('The scores should be read from file ' + $score_txt_file + ' ! ');
	var $scores = '<tr><th></th><th>Player </th><th></th><th>Score</th></tr>';
		$scores += '<tr><td> 1 : </td><td id="player_1">Flyzy</td><td> : </td><td class="hi_score">999</td></tr>';
		$scores += '<tr><td> 2 : </td><td id="player_2">The Fly</td><td> : </td><td class="hi_score">550</td></tr>';
		$scores += '<tr><td> 3 : </td><td id="player_3">Joeri</td><td> : </td><td class="hi_score">500</td></tr>';
		$scores += '<tr><td> 4 : </td><td id="player_4">De Joeri</td><td> : </td><td class="hi_score">450</td></tr>';
		$scores += '<tr><td> 5 : </td><td id="player_5">Ikke</td><td> : </td><td class="hi_score">400</td></tr>';
		$scores += '<tr><td> 6 : </td><td id="player_6">Me</td><td> : </td><td class="hi_score">350</td></tr>';
		$scores += '<tr><td> 7 : </td><td id="player_7">Myself</td><td> : </td><td class="hi_score">300</td></tr>';
		$scores += '<tr><td> 8 : </td><td id="player_8">I</td><td> : </td><td class="hi_score">250</td></tr>';
		$scores += '<tr><td> 9 : </td><td id="player_9">Den Deze</td><td> : </td><td class="hi_score">200</td></tr>';
		$scores += '<tr><td>10 : </td><td id="player_10">Fly</td><td> : </td><td class="hi_score">150</td></tr>';
	$("#top_ten").html($scores);
//	return make_score_file();
}

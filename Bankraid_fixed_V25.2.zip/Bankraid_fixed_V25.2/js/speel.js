//onload=function(){						//While loading page...
$(document).ready(function() {
	var $op_af = "op";
	var $level = 1;
	check_save_possible();					//Check if the used browser supports the File APIs, used for saving
	$("div").stop(true, true);
	load_levels();							//Load all standard and extra levels
	load_moves();							//Load all standard and extra levels sollutions
	get_scores();							//
	toon_intro($op_af);						//
});

var $op = '<a href="#" onclick="geluid(&#34;op&#34;)">Sound on</a>';
var $af = '<a href="#" onclick="geluid(&#34;af&#34;)">Sound off</a>';

function lees_richting_aan() {				//React on playing and clock keys
	$(document).unbind("keydown");
	$(document).stop( true, true ).keydown(function(e) {
		e.preventDefault(); 				// prevent the default action (like scroll)
		switch(e.which) {
			case 37: // left
				$direction = "left";
				go_left($("#mover"));
				return $direction;
			break;
			case 38: // up
				$direction = "up";
				go_up($("#mover"));
				return $direction;
			break;
			case 39: // right
				$direction = "right";
				go_right($("#mover"));
				return $direction;
			break;
			case 40: // down
				$direction = "down";
				go_down($("#mover"));
				return $direction;
			break;
			case 84: // "t" : tick the clock again
				countdown_trigg();
				return;
			break;
			case 73: // "i" : initiate last 10 seconds
				countdown_clear();
				countdown_init();
				return;
			break;
			case 67: // "c" : count again
				countdown_clear();
				return;
			break;
			case 69: // "e" : end/exit
				check_score(-2);
				return;
			break;
			case 88: // "x" : xplode
				countdown_end();
				return;
			break;
			default: return; 				// exit this handler for other keys
		};
	});
}

function lees_richting_half() {				//React only on the clock keys
	$(document).unbind("keydown");
	$(document).stop( true, true ).keydown(function(e) {
		e.preventDefault(); 				// prevent the default action (like scroll)
		switch(e.which) {
			case 84: // "t" : tick the clock again
				countdown_trigg();
				return;
			break;
			case 73: // "i" : initiate last 10 seconds
				countdown_clear();
				countdown_init();
				return;
			break;
			case 67: // "c" : count again
				countdown_clear();
				return;
			break;
			case 69: // "e" : end/exit
				check_score(-2);
				return;
			break;
			case 88: // "x" : xplode
				countdown_end();
				return;
			break;
			default: return; 				// exit this handler for other keys
		};
	});
}

function lees_richting_uit() {				//Don't react on pressing any key in the game
	$(document).unbind("keydown");
	console.log("Don't see pressed keys!");
	return $("#mover").rotationInfo().deg;
}

function toon_oplossing($level) {			//Show the sollution of a specific level
	$('#body_title span').html($('#body_title span').html()=="Demo"?"Demo":"This is how it's done!");
	reset_labyrinth();
	$('#auto_indicator').html("1");
	$('#marge_rechts b').html($level);
	toon_labyrinth_level();
	$level = $level>0?$level:$('#marge_rechts b').html();
	autospeel($level);
}

function autospeel($level) {				//Run the sollution of a specific level
	$("#score").addClass("null");
	$("#walkers_left").addClass("null");
	$these_moves = get_moves($level);
	Place_mover();
	$.each( $these_moves, function( $i, $value ) {
		switch($value) {
			case "4": // left
				setTimeout(function(){
					go_left($('#mover'));
				},600 + ( $i * 600 ));
			break;
			case "5": // up
				setTimeout(function(){
					go_up($('#mover'));
				},600 + ( $i * 600 ));
			break;
			case "2": // right
				setTimeout(function(){
					go_right($('#mover'));
				},600 + ( $i * 600 ));
			break;
			case "3": // down
				setTimeout(function(){
					go_down($('#mover'));
				},600 + ( $i * 600 ));
			break;
			default: break; 				// exit this handler for other keys
		};
	});
}

function wisselVak(showVak) {				//Set up a specific chosen screen
	$('#pre_body').attr({'class':'hidden'});
	$('#body').attr({'class':'hidden'});
	$('#end_body').attr({'class':'hidden'});
	$('#menu').attr({'class':'hidden'});
	$('#menu_title').attr({'class':'hidden'});
	$('#top_ten_scores').attr({'class':'hidden'});
	$('#top_ten_scores_title').attr({'class':'hidden'});
	$('#'+showVak).removeAttr('class');
}

function toon_demo() {						//Show examples continiously
	var $op_af = $('#menu_knop li:nth-child(2)').html();
	$("#score").addClass("null");
	$("#walkers_left").addClass("null");
	$('#body_title span').html("Demo");
	$level = randomize(1, $last_level);	
	toon_oplossing($level);
}

function geluid($op_af) {					//Turn on/off the sound
	$op_af = ($op_af === "op") ? "op" : "af";
	$('#menu_knop li:nth-child(2)').html(($op_af === "af") ? $op : $af);
	$('#zij_knop li:nth-child(1)').html(($op_af === "af") ? $op : $af);
	$('#zij_knop_scores li:nth-child(1)').html(($op_af === "af") ? $op : $af);
	return($op_af);
}

function speel($level) {					//Play certain level with game set according to previous handling
	$('#body_title span').html("Defuse a bomb, any bomb!");
	reset_labyrinth();
	$level=='0'?reset_game():$level=='-1'?walkers_left()?klok():setTimeout("check_score(-1)", 10):klok();
	toon_labyrinth_level();
	setTimeout(function(){
		Place_mover();
	},500);
	$direction = lees_richting_aan();
}

function reset_game() {						//Minimum reset values to start all over
	$('#level b').html('1');
	$("#score_value").html('0');
	reset_walkers_left();
	reset_labyrinth();
	klok();
	console.log('Game reset');
}

function do_nothing($action) {				//Hollow function for when nothing needs to be done in a shorted if instruction
	var $nothing = false;
	var $nothing_false_count = 0;
	$action ? $nothing_false_count++ : $nothing = true;
}

(function ($) {								//Function to switch between classes
    $.fn.replaceClass = function (pFromClass, pToClass) {
        return this.removeClass(pFromClass).addClass(pToClass);
    };
}(jQuery));


Important:

Bankraid works only 
fully when opened 
with the web browser 
�Opera� or �Chrome�.


How to play :

- Open �Bankraid_js.html� with the web browser �Opera� or �Chrome�.
- Try to get to any of the bombs through the labyrinth.
- You�ve got only 60 seconds before the bombs explode.
- A wall can only be moved by pushing it, if the next position is void.
- Every labyrinth is solvable (click �Show solution� to see how).
- You start with 7 walkers, 6 on hold, 1 in the labyrinth.
- Showing solutions, explosions and cheating costs a walker every time.
- When stuck in a labyrinth you can click �Show solution�, then �Play again�.
- Every walker you have left at the end, gets you 10 extra bonus points each.
- High scores and own made labyrinths are only saved to your 
  download directory after clicking �Exit�.
- Copy, after you exit the game the files "scores_file.js" and "extra_levels.js" 
  from your download directory to the game directory "Bankraid/js" 
  and replace the old one!
- When �Exit� is clicked multiple times, the last one must be kept with 
  the index removed.
  (example 1 : extra_levels (5).js becomes extra_levels.js)
  (example 2 : scores_file (5).js becomes scores_file.js)


History : 

�Bombsweeper� was original a Nintendo 
Multi Screen �Game & Watch� monochrome lcd video game, 
released in June of 1987.
The game was copied short after as �Boom finder� 
by I.T.C. (or Videojet) and �Bankraid� by Systema.
In 1996 i made a windows version myself as project.
In 2000 a version for Gameboy color, called �Dynamite� became available.
In 2002 a version for NES became available.
In 2006 a version for NOKIA & Ti85 (asm) became available.
In 2007 a version for Java became available.
In 2011 a version for iTunes & iPad became available.


